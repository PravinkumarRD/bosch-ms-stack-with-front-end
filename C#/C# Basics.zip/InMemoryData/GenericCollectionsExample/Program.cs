﻿using System.Collections.Generic;

namespace GenericCollectionsExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            List<int> list = new List<int>();
            list.Add(100);
            list.Add(200);
            list.Add(300);
            list.Add(400);
            int firstNumber = list[0];

            foreach (int no in list)
            {
                Console.WriteLine(no);
            }
            */
            /*
            Stack<string> books=new Stack<string>();
            books.Push("Book-1");
            books.Push("Book-2");
            books.Push("Book-3");
            books.Push("Book-4");

            //string firstBook = books.Pop();
            string firstBook = books.Peek();
            Console.WriteLine(firstBook);
            Console.WriteLine("");
            foreach (string book in books)
            {
                Console.WriteLine(book);
            }
            */
            /*Queue<int> tickets= new Queue<int>();
            tickets.Enqueue(1);
            tickets.Enqueue(2);
            tickets.Enqueue(3);
            tickets.Enqueue(4);
            tickets.Enqueue(5);
            //int firstTicketNumber = tickets.Dequeue();
            int firstTicketNumber = tickets.Peek();
            Console.WriteLine(firstTicketNumber);
            Console.WriteLine("");
            foreach (int ticketNo in tickets)
            {
                Console.WriteLine(ticketNo);
            }*/
            Dictionary<int,string> employees = new Dictionary<int,string>();
            employees.Add(1000, "Alisha C.");
            employees.Add(1001, "Ali C.");
            employees.Add(1002, "Manisha C.");
            employees.Add(1003, "Pravin C.");
            foreach (int key in employees.Keys)
            {
                Console.WriteLine($"Employee Id {key} and name is {employees[key]}");
            }
            Console.ReadKey();
        }
    }
}








