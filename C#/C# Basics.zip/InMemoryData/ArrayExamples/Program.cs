﻿namespace ArrayExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("1-D Array Example!");
             string[] offices = new string[3];// { "Bangalore", "Chennai", "Delhi" };
             offices[0] = "Bangalore";
             offices[1] = "Chennai";
             offices[2] = "Delhi";
             for (int i = 0; i < offices.Length; i++)
             {
                 Console.WriteLine(offices[i]);
             }*/
            /*Console.WriteLine("2-D Array Example!");
            double[,] data = new double[2, 2] { { 1, 1 }, { 1, 2 } };
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    Console.Write($"{data[i, j]} \t");
                }
                Console.WriteLine("");
            }*/
           Console.WriteLine("Jagged Array Array Example!");
            string[][] subjects = new string[4][];
            subjects[0] = new string[] { "Subject-1", "Subject-2" };
            subjects[1] = new string[] { "Subject-1" };
            subjects[2] = new string[] { "Subject-1", "Subject-2", "Subject-3", "Subject-4" };
            subjects[3] = new string[] { "Subject-1", "Subject-2", "Subject-3" };

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"Row Number is - {i}");
                for (int j = 0; j < subjects[i].Length; j++)
                {
                    Console.Write($"{subjects[i][j]} \t");
                }
                Console.WriteLine("");
            }
           
            Console.ReadKey();
        }
    }
}
