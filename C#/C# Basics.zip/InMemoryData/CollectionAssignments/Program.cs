﻿namespace CollectionAssignments
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Method Chaining Pattern
            var cityWiseCustomers = GetAllCustomer().Where(c=>c.City!="London").GroupBy(c => c.City).Select(res => new CityWiseCustomers { City = res.Key, Count = res.Count() });
            //var cityWiseCustomers = from customer in GetAllCustomer()
            //                        group customer by customer.City into k
            //                        select new CityWiseCustomers { Count = k.Count(), City = k.Key };
            //List<CityWiseCustomers> cityWiseCustomers = new List<CityWiseCustomers>();
            //foreach (Customer customer in GetAllCustomer())
            //{
            //    CityWiseCustomers result =cityWiseCustomers.Find(delegate (CityWiseCustomers res) { return res.City == customer.City; });
            //    if (result == null) 
            //    {
            //        result = new CityWiseCustomers();
            //        result.City = customer.City;
            //        result.Count = 1;
            //        cityWiseCustomers.Add(result);
            //    }
            //    else
            //    {
            //        result.Count++;
            //    }
            //}
            foreach (CityWiseCustomers customer in cityWiseCustomers)
            {
                Console.WriteLine($"In city {customer.City} there is/are {customer.Count} number of customer(s)!");
            }
            Console.ReadKey();
        }
        private static List<Customer> GetAllCustomer()
        {
            return new List<Customer>()
            {
                new(){CustomerId = 1, ContactName="Alisha C.",City="Mumbai"},
                new(){CustomerId = 2, ContactName="Manas Jha",City="Mumbai"},
                new(){CustomerId = 3, ContactName="Maria Johns",City="Berlin"},
                new(){CustomerId = 4, ContactName="John Marks",City="London"},
            };
        }
    }
}
