﻿namespace CollectionAssignments
{
    internal class CityWiseCustomers
    {
        public int Count { get; set; }
        public string City { get; set; } = string.Empty;
    }
}
