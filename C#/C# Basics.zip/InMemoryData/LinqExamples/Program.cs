﻿using System.Xml.Linq;

namespace LinqExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var allCustomers = from customer in GetAllCustomer()
                                   //where customer.City.EndsWith("i")
                               orderby customer.City, customer.ContactName
                               select customer;
            foreach (var cust in allCustomers)
            {
                Console.WriteLine($"Customer {cust.ContactName} lives in city {cust.City}!");
            }
            Console.WriteLine("");
            var CustomerOrders = from customer in GetAllCustomer()
                                 join
                                 order in GetAllOrders()
                                 on customer.CustomerId equals order.CustomerId
                                 join
                                 product in GetAllXmlProduct()
                                 on order.ProductId equals product.ProductId
                                 select new { CustomerName = customer.ContactName, LivingCity = customer.City, OrderId = order.OrderId, ODate = order.OrderDate, ReqDate = order.RequiredDate, TotalQuantity = order.Quantity, ProductName=product.ProductName, Compnay=product.CompanyName, PayableAmount=order.Quantity * product.UnitPrice };

            foreach (var custOrd in CustomerOrders)
            {
                Console.WriteLine($"Customer {custOrd.CustomerName} from city {custOrd.LivingCity} has placed an order {custOrd.OrderId} on {custOrd.ODate} with Quantity {custOrd.TotalQuantity}! The delivery date for this order is - {custOrd.ReqDate}! Product name is {custOrd.ProductName} belongs to company {custOrd.Compnay}! Total Payable amount in INR {custOrd.PayableAmount}/- !");
            }
        }
        private static List<Customer> GetAllCustomer()
        {
            //Collection Initializer
            return new List<Customer>()
            {
                //Object Initializer
                new(){CustomerId = 1, ContactName="Alisha C.",City="Mumbai"},
                new(){CustomerId = 2, ContactName="Manas Jha",City="Mumbai"},
                new(){CustomerId = 3, ContactName="Maria Johns",City="Berlin"},
                new(){CustomerId = 4, ContactName="John Marks",City="London"},
            };
        }
        private static List<Order> GetAllOrders()
        {
            return new List<Order>()
            {
                new Order() { CustomerId = 1, OrderId = 1, OrderDate=DateTime.Now, RequiredDate=DateTime.Now.AddDays(2), Quantity=20, ProductId=1001 },
                new Order() { CustomerId = 1, OrderId = 2, OrderDate=DateTime.Now, RequiredDate=DateTime.Now.AddDays(2), Quantity=30,ProductId=1003 },
                new Order() { CustomerId = 3, OrderId = 3, OrderDate=DateTime.Now, RequiredDate=DateTime.Now.AddDays(2), Quantity=25, ProductId=1002 },
            };
        }
        private static List<Product> GetAllXmlProduct()
        {
            var products = from xmlProduct in XElement.Load(@"D:\WebxTraining\Bosch-MS-Stack\C# Basics\InMemoryData\LinqExamples\ProductsList.xml").Elements()
                           select new Product
                           {
                               ProductId = int.Parse(xmlProduct.Attribute("ProductId").Value),
                               ProductName = xmlProduct.Attribute("ProductName").Value,
                               UnitPrice = double.Parse(xmlProduct.Attribute("UnitPrice").Value),
                               CompanyName = xmlProduct.Attribute("CompanyName").Value
                           };
            return products.ToList();
        }
    }
}
