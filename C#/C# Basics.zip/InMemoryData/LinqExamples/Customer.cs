﻿namespace LinqExamples
{
    internal class Customer
    {
        public int CustomerId { get; set; }
        public string? ContactName { get; set; }
        public string? City { get; set; }
    }
}
