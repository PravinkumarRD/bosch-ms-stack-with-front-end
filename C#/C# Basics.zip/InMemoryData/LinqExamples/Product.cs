﻿namespace LinqExamples
{
    internal class Product
    {
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public string? CompanyName { get; set; }
        public double UnitPrice { get; set; }
    }
}
