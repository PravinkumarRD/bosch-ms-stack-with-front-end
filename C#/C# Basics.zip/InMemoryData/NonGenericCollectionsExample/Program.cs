﻿using System.Collections;

namespace NonGenericCollectionsExample
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ArrayList
            ArrayList zipcodes = new ArrayList();
            //Boxing - Converting Int to Object [Value Type to Reference Type]
            zipcodes.Add(411051);
            zipcodes.Add(411052);
            zipcodes.Add(411004);
            zipcodes.Add(411023);
            //Unboxing - Converting Object to Int  [Reference Type to Value Type]
            int firstZipcode = Convert.ToInt32(zipcodes[0]);
            Stack books=new Stack();
            Queue tickets=new Queue();
            Hashtable hashtable = new Hashtable();
            
            
        }
    }
}
