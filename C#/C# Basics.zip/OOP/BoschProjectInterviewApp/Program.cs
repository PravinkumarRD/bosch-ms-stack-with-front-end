﻿namespace BoschProjectInterviewApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Employee employee = new Employee();
                employee.Selected += new BoschInterview(SQLServerDb);
                employee.Rejected += OracleDb;
                employee.Selected += SendEmailToBoss;
                employee.EmployeeId = 1;
                employee.EmployeeName = "Test";
                employee.City = "Test City";
                employee.TotalMarks = 97;
                if (employee.TotalMarks<95)
                {
                    employee.Selected -= SendEmailToBoss;
                }
                string workingCity = "Home Town";
                Console.WriteLine(employee.CalculateResult(employee.TotalMarks, ref workingCity));
                Console.WriteLine($"Your working city will be {workingCity}");
                employee.PrintBoschCities("Bangalore", "Chennai");
                employee.PrintBoschCities("Bangalore", "Chennai", "Delhi", "Pune");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();
        }
        private static void OracleDb()
        {
            Console.WriteLine("Employees data stored in Oracle DB!");
        }
        private static void SQLServerDb()
        {
            Console.WriteLine("Employees data stored in Micrsoft SQL Server DB!");
        }
        private static void SendEmailToBoss()
        {
            Console.WriteLine("Email has been sent to my Boss!!!");
        }
    }
}
