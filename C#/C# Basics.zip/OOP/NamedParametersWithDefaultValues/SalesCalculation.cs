﻿namespace NamedParametersWithDefaultValues
{
    internal class SalesCalculation
    {
        //Default/Optional parameters must be the last parameter in your function
        public double SalesNetProfit(double cogs, double expense = 15000, double actualSales = 0, int gstPercent = 0)
        {
            double gstAmount = actualSales * gstPercent / 100;
            return actualSales - (cogs + expense + gstAmount);
        }
    }
}
