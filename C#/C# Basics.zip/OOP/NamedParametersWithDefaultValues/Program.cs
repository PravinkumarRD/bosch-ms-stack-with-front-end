﻿namespace NamedParametersWithDefaultValues
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SalesCalculation sales=new();
            //Named Parameters
            Console.WriteLine(sales.SalesNetProfit(actualSales:150000,cogs:12000,gstPercent:18));
        }
    }
}
