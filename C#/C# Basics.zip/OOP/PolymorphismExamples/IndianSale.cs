﻿//Profit = Incoming Money - Outgoing Money
//Outgoing Money Parameters - cogs, expense, gstAmount
//Incoming Money Parameters - actualSales

namespace PolymorphismExamples
{
    internal class IndianSale
    {
        public virtual int GetTaxPercent(string field)
        {
            if (field == "IT")
            {
                return 18;
            }
            return 10;
        }
        public double SalesNetProfit(double cogs, double expense, double actualSales)
        {
            return actualSales - (cogs + expense);
        }
        public double SalesNetProfit(double cogs, double expense, double actualSales,int gstPercent)
        {
            double gstAmount = actualSales * gstPercent / 100;
            return actualSales - (cogs + expense + gstAmount);
        }
    }
}
