﻿namespace PolymorphismExamples
{
    internal class DubaiSale : IndianSale
    {
        public double SalesNetProfit(double cogs, double expense, double actualSales, int gstPercent, double transportCost)
        {
            double gstAmount = actualSales * gstPercent / 100;
            return actualSales - (cogs + expense + gstAmount + transportCost);
        }
        public override int GetTaxPercent(string field)
        {
            if (field == "AUTOMOBILE") { return 8; }
            return 12;
        }
    }
}
