﻿namespace PolymorphismExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IndianSale indianSale = new DubaiSale();
            Console.WriteLine(indianSale.SalesNetProfit(12000, 13000, 150000));
            Console.WriteLine(indianSale.SalesNetProfit(12000, 13000, 150000, indianSale.GetTaxPercent("FOOD")));
            //Console.WriteLine(indianSale.SalesNetProfit(12000, 13000, 150000, indianSale.GetTaxPercent("FOOD"), 1500));
        }
    }
}
