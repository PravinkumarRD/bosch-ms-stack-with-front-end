﻿namespace DifferentClasses
{
    internal static class PrimeCustomerExentionMethods
    {
        public static string EarlyAccess(this PrimeCustomer customer,DateTime startDate)
        {
            return $"Prime Early Access Starts from {startDate}!";
        }
    }
}
