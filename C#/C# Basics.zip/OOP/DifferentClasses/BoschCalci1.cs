﻿namespace DifferentClasses
{
    internal partial class BoschCalci
    {
        public int Addition(int num1, int num2)
        {
            return num1 + num2;
        }
    }

}
