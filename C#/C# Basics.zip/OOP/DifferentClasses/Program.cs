﻿namespace DifferentClasses
{
  
    internal class Program
    {
        static void Main(string[] args)
        {
            //Object Initialzer
            PrimeCustomer customer = new() { ContactName = "Alisha C.", Address = "Moon City", City = "Mumbai", Phone = "23929823", Email = "alisha.c@bosch.com" };
            customer.ChangeAddress(customer.Address, "Suncity");
            Console.WriteLine(customer.EarlyAccess(DateTime.Now.AddDays(3)));
            BoschCalci calci = new BoschCalci();

            Console.ReadKey();
        }
    }

    class A
    {
        public int X { get; set; }
    }
    class B : A
    {
        public int Y { get; set; }
    }
    class C : B
    {
        public int Z { get; set; }
    }
}
