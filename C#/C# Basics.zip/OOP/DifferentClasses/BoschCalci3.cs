﻿namespace DifferentClasses
{
    internal partial class BoschCalci
    {
        public int Multiplication(int num1, int num2)
        {
            return num1 * num2;
        }
    }
}
