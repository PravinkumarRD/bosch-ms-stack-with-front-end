﻿namespace DifferentClasses
{
    //Customer IS-A Person
    internal class Customer : Person
    {
        public Customer() 
        {
            Console.WriteLine("Concrete Class - Customer Constructor Executed!");
        }
        public int CustomerId { get; set; }
        public override bool ChangeAddress(string oldAddress, string newAddress)
        {
            Console.WriteLine($"Person {ContactName} has changed his/her address from {oldAddress} to {newAddress}!");
            return true;
        }
    }
}
