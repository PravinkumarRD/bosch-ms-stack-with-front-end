﻿namespace DifferentClasses
{
    //You can not create an instance of Abstract class
    abstract class Person
    {
        protected Person()
        {
            Console.WriteLine("Abstract Class Constructor Executed!");
        }
        public int SocialId { get; set; }
        public required string ContactName { get; set; }
        public required string Address { get; set; }
        public required string City { get; set; }
        public required string Phone { get; set; }
        public required string Email { get; set; }
        public abstract bool ChangeAddress(string oldAddress, string newAddress);
    }
}
