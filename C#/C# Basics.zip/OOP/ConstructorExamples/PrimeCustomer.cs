﻿namespace ConstructorExamples
{
    //PrimeCustomer IS-A Customer
    internal class PrimeCustomer : Customer
    {
        //public PrimeCustomer()
        //{
        //    Console.WriteLine("Default Constructor Of PrimeCustomer Class!");
        //}
        //public PrimeCustomer(string name,string city):base(name, city)
        public PrimeCustomer(string name, string city)
        {
            
        }
    }
}
