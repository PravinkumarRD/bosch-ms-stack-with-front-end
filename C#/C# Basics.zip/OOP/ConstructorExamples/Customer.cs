﻿namespace ConstructorExamples
{
    internal class Customer
    {
        static Customer()
        {
            Console.WriteLine("This is a Static Constructor of Customer Class!");
        }
        public Customer()
        {
            CustomerId = -1;
            Console.WriteLine("Default Constructor Of Customer Class!");
        }
        //public Customer(string name, string city):this()
        public Customer(string name, string city)
        {
            ContactName = name;
            City = city;
        }
        //public Customer(Customer customer):this()
        public Customer(Customer customer)
        {
            ContactName = customer.ContactName;
            City = customer.City;
        }
        public int CustomerId { get; set; }
        public string ContactName { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        protected int PinNumber { get; set; }
        public string GetCustomerInfo()
        {
            return $"Customer {ContactName} lives in city {City}!";
        }
    }
}
