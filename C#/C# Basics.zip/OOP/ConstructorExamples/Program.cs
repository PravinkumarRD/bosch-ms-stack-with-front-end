﻿namespace ConstructorExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Customer customer1 = new("Alisha C.", "Mumbai");
            //Customer customer2 = new(customer1);
            //Console.WriteLine(customer1.CustomerId);
            //Console.WriteLine(customer1.GetCustomerInfo());
            //Console.WriteLine(customer2.GetCustomerInfo());
            PrimeCustomer customer = new("Pravinkumar R. D", "Pune");
            Console.WriteLine(customer.CustomerId);
            Console.WriteLine(customer.GetCustomerInfo());
            Console.ReadKey();
        }
    }
}
