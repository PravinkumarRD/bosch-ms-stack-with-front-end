﻿namespace InterfaceExamples
{
    internal interface IChemistry
    {
        string ChemistryDepartmentLocation();
    }
}
