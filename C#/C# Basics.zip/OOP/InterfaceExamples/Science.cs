﻿namespace InterfaceExamples
{
    internal class Science :IScience
    {
        string IBiology.BiologyDepartmentLocation()
        {
            return "South";
        }

        string IChemistry.ChemistryDepartmentLocation()
        {
            return "North";
        }

        string IPhysics.PhysicsDepartmentLocation()
        {
            return "East";
        }
    }
}
