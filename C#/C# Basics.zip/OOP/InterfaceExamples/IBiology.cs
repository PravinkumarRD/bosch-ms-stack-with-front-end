﻿namespace InterfaceExamples
{
    internal interface IBiology
    {
        string BiologyDepartmentLocation();
    }
}
