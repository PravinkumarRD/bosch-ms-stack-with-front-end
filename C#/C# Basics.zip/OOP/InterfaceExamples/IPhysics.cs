﻿namespace InterfaceExamples
{
    internal interface IPhysics
    {
        string PhysicsDepartmentLocation();
    }
}
