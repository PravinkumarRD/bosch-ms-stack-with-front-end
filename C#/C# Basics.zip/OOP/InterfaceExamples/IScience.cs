﻿namespace InterfaceExamples
{
    internal interface IScience : IPhysics, IChemistry, IBiology
    {
    }
}
