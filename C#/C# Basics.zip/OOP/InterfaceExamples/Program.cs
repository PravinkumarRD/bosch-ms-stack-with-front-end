﻿namespace InterfaceExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IPhysics physics = new Science();
            Console.WriteLine(physics.PhysicsDepartmentLocation());
            IChemistry chemistry = new Science();
            Console.WriteLine(chemistry.ChemistryDepartmentLocation());
            IBiology biology=new Science();
            Console.WriteLine(biology.BiologyDepartmentLocation());
            IScience science = new Science(); //Will have access to all three department methods
        }
    }
}
