﻿namespace Library.Management.Models.OCP
{
    public class RegularBookFineCalculator : FineCalculator
    {
        public override decimal CalculateFine(int overdueDays)
        {
            return overdueDays * 1.0m; // $1 per day
        }
    }
}
