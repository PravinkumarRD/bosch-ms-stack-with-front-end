﻿namespace Library.Management.Models.OCP
{
    public class RareBookFineCalculator : FineInterstCalculator
    {
        public override decimal CalculateFine(int overdueDays)
        {
            return overdueDays * 5.0m; // $5 per day
        }
        public override decimal CalculateFineIntrest(int overdueDays)
        {
            return 10;
        }
    }
}
