﻿namespace Library.Management.Models.OCP
{
    public abstract class FineCalculator
    {
        public abstract decimal CalculateFine(int overdueDays);
    }
    public abstract class FineInterstCalculator:FineCalculator
    {
        public abstract decimal CalculateFineIntrest(int overdueDays);
    }
}
