﻿using Library.Management.Models.OCP;
using Library.Management.Models.SRP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Management.Models.DIP
{
    public class LibraryService
    {
        private readonly IFineService _fineService;

        public LibraryService(IFineService fineService)
        {
            _fineService = fineService;
        }

        public void ProcessFine(Member member, FineCalculator fineCalculator, int overdueDays)
        {
            decimal fine = _fineService.CalculateFine(fineCalculator, overdueDays);
            // Process fine payment
        }
    }
}
