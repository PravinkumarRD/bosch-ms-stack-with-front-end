﻿using Library.Management.Models.OCP;

namespace Library.Management.Models.DIP
{
    public interface IFineService
    {
        decimal CalculateFine(FineCalculator fineCalculator, int overdueDays);
    }
}
