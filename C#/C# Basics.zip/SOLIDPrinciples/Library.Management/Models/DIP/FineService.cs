﻿using Library.Management.Models.OCP;

namespace Library.Management.Models.DIP
{
    public class FineService : IFineService
    {
        public decimal CalculateFine(FineCalculator fineCalculator, int overdueDays)
        {
            return fineCalculator.CalculateFine(overdueDays);
        }
    }
}
