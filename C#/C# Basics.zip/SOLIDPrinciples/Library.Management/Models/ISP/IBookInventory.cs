﻿using Library.Management.Models.SRP;

namespace Library.Management.Models.ISP
{
    public interface IBookInventory
    {
        void AddBook(Book book);
        void RemoveBook(Book book);
    }
}
