﻿using Library.Management.Models.SRP;

namespace Library.Management.Models.ISP
{
    public class BookInventory : IBookInventory
    {
        public void AddBook(Book book)
        {
            // Add book to inventory
        }

        public void RemoveBook(Book book)
        {
            // Remove book from inventory
        }
    }
}
