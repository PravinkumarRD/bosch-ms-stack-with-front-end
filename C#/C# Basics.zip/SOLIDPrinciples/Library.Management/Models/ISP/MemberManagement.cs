﻿using Library.Management.Models.SRP;

namespace Library.Management.Models.ISP
{

    public class MemberManagement : IMemberManagement,IMemberDiscount
    {
        public double ApplyDiscount(bool isMember)
        {
            throw new NotImplementedException();
        }

        public void RegisterMember(Member member)
        {
            // Register a new member
        }

        public void UnregisterMember(Member member)
        {
            // Unregister a member
        }
    }
}
