﻿using Library.Management.Models.SRP;

namespace Library.Management.Models.ISP
{
    public interface IMemberManagement
    {
        void RegisterMember(Member member);
        void UnregisterMember(Member member);
    }
    public interface IMemberDiscount
    {
        double ApplyDiscount(bool isMember);
    }
}
