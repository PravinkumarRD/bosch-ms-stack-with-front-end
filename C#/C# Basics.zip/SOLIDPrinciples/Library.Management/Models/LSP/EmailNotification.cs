﻿namespace Library.Management.Models.LSP
{
    public class EmailNotification : Notification
    {
        public override void Send(string message)
        {
            // Send email
        }
    }
}
