﻿namespace Library.Management.Models.LSP
{
    public abstract class Notification
    {
        public abstract void Send(string message);
    }
}
