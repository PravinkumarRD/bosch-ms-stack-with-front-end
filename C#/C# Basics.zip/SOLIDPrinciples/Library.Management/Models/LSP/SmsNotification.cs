﻿namespace Library.Management.Models.LSP
{
    public class SmsNotification : Notification
    {
        public override void Send(string message)
        {
            // Send SMS
        }
    }
}
