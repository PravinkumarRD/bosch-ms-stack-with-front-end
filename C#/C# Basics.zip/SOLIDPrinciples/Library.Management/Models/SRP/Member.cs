﻿namespace Library.Management.Models.SRP
{
    public class Member
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public List<Book> BorrowedBooks { get; set; } = new List<Book>();
    }
}
