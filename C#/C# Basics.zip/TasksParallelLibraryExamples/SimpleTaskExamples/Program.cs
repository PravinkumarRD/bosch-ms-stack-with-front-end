﻿namespace SimpleTaskExamples
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Main Method Started on {Thread.CurrentThread.ManagedThreadId}");
            /*Task task1 = new Task(new Action(() => 
            {
                Console.WriteLine($"Task-1 Started on {Thread.CurrentThread.ManagedThreadId}");
            }));
            task1.Start();
            //const int square = (num) => { return num * num; };
           Task<string> task2 = new Task<string>(() => { return "Welcome To Bosch Pvt. Ltd. India"; });
            task2.Start();
            Console.WriteLine(task2.Result);*/
            /*Task.Run(() => {
                Console.WriteLine($"Task-1 Started on {Thread.CurrentThread.ManagedThreadId}");
            });
            Task<int> task = Task.Run(() => 1000);
            Console.WriteLine(task.Result);*/
            Task<int> t1 = Task.Run(() => { Task.Delay(3000).Wait();  return 1000; });
            Task<int> t2 = Task.Run(() => { Task.Delay(4000).Wait(); return 2000; });
            Task<int> t3 = Task.Run(() => { Task.Delay(1000).Wait(); return 3000; });
            Task.WaitAll(t1, t2, t3);
            //var taskResult = Task.WhenAny(t1, t2, t3).Result;
            Console.WriteLine($"Task - 1 Value - {t1.Result}");
            Console.WriteLine($"Task - 2 Value - {t2.Result}");
            Console.WriteLine($"Task - 3 Value - {t3.Result}");
            //Console.WriteLine(taskResult.Result);
        }

    }
}
