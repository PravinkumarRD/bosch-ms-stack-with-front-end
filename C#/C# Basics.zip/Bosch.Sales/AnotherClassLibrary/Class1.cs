﻿using Bosch.Sales.Calculation;

namespace AnotherClassLibrary
{
    public class Class1:Parent
    {
        public Class1()
        {
            
        }
    }
}
