﻿using Bosch.Sales.Calculation;

namespace AnotherClassLibrary
{
    internal class Class2
    {
        Parent p1;
        public Class2()
        {
            p1 = new Parent();
        }
    }
}
