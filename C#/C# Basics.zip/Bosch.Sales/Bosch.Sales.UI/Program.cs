﻿using BSC = Bosch.Sales.Calculation;

namespace Bosch.Sales.UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            BSC.Sales sales = new BSC.Sales();
            Console.WriteLine(sales.SalesNetProfit(12000, 13000, 150000));
            Console.WriteLine(sales.SalesNetProfit(12000, 13000, 150000, 18));
            
            Console.ReadKey();
        }
    }
}
