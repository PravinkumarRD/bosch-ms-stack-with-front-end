﻿namespace Bosch.Sales.Calculation
{
    public class Parent
    {
        private int Prop1 { get; set; }
        protected int Prop2 { get; set; }
        public int Prop3 { get; set; }
        internal int Prop4 { get; set; }
        protected internal int Prop5 { get; set; }

    }
}
