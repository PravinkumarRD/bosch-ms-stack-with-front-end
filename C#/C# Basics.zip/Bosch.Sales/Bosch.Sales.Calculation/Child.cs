﻿namespace Bosch.Sales.Calculation
{
    public class Child:Parent
    {
        public Child()
        {
            
        }
    }
}
