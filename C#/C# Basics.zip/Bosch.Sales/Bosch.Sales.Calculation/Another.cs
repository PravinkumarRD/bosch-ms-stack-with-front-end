﻿namespace Bosch.Sales.Calculation
{
    internal class Another
    {
        Parent p1 = new();
        public Another()
        {
            
        }
    }
}
