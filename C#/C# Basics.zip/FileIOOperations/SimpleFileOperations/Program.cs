﻿using System.IO;

namespace SimpleFileOperations
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\WebxTraining\Bosch-MS-Stack\Logs.txt";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("File you are looking for does not exist!");
                File.Create(filePath);
            }
            //File.WriteAllText(filePath, "Hello Bosch, Global Company!");
            File.AppendAllText(filePath, "Hello From Bosch Global!");
            Console.WriteLine(File.ReadAllText(filePath));
            Console.ReadKey();
        }
    }
}
