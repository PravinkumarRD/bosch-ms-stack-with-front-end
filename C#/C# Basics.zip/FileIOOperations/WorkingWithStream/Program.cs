﻿namespace WorkingWithStream
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\WebxTraining\Bosch-MS-Stack\Messages.txt";
            //using(StreamWriter SW=new StreamWriter(filePath, true))
            //{
            //    SW.WriteLine("Welcome To India!");
            //    SW.WriteLine("Welcome To Karnataka!");
            //    SW.WriteLine("Welcome To Bangalore!");
            //    SW.WriteLine("Welcome To Bosch!");
            //    SW.Close();
            //}
            using (StreamReader SR=new StreamReader(filePath))
            {
                //Console.WriteLine(SR.ReadToEnd());
                while (SR.Peek()!=-1)
                {
                    Console.WriteLine(SR.ReadLine());
                }
                SR.Close();
            }
        }
    }
}
