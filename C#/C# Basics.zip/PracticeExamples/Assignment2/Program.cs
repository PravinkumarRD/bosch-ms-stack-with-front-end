﻿namespace Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter your name - ");
                string name = Console.ReadLine();
                Console.WriteLine("Please enter your age - ");
                int age = int.Parse(Console.ReadLine());
                if (age < 70)
                {
                    //Interpolation syntax
                    Console.WriteLine($"Hello, {name} - Welcome To Racing Club!");
                }
                else
                {
                    Console.WriteLine($"Sorry! {name}, We can not allow your entry in our race club!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
