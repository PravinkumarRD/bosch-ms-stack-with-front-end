﻿namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome To Bosch!");
            Console.ReadKey();
        }
    }
}
