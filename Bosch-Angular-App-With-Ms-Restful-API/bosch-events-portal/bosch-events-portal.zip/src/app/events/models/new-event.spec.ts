import { NewEvent } from './new-event';

describe('NewEvent', () => {
  it('should create an instance', () => {
    expect(new NewEvent()).toBeTruthy();
  });
});
