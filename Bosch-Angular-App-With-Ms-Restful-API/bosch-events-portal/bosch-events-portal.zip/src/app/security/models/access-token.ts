export class AccessToken {
    email: string;
    role: string;
    token: string;
}
