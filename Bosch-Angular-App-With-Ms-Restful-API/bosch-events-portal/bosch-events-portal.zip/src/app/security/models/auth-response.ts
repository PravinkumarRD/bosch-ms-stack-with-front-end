import { AccessToken } from "./access-token";

export class AuthResponse {
    accessToken: AccessToken;
    message: string;
    success: boolean;
}
