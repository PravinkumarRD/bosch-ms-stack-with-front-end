import { AccessToken } from './access-token';

describe('AccessToken', () => {
  it('should create an instance', () => {
    expect(new AccessToken()).toBeTruthy();
  });
});
