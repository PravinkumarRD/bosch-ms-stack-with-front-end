import { Component } from '@angular/core';

@Component({
  selector: 'bosch-bosch-home',
  standalone: true,
  imports: [],
  templateUrl: './bosch-home.component.html',
  styleUrl: './bosch-home.component.css'
})
export class BoschHomeComponent {

}
